#include "StateMachine.h"
#include "States/SetupState.h"

SetupState setupState;

void StateMachine::begin() {
    changeState(&setupState);
}

void StateMachine::update() {
    if (currentState) {
        currentState->onUpdate();
    }
}

void StateMachine::changeState(State* newState) {
    if (currentState) {
        currentState->onExit();
    }
    currentState = newState;
    if (currentState) {
        currentState->onEnter();
    }
}
