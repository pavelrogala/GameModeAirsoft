#ifndef STATE_MACHINE_H
#define STATE_MACHINE_H

#include "DisplayManager.h"

class State {
public:
    virtual void onEnter(StateMachine* sm) = 0;
    virtual void onUpdate() = 0;
    virtual void onExit() = 0;
};

class StateMachine {
public:
    void begin();
    void update();
    void changeState(State* newState);
    DisplayManager displayManager;

private:
    State* currentState = nullptr;
};

#endif
