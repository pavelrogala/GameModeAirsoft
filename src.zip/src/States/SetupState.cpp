#include "SetupState.h"
#include <Arduino.h>

void SetupState::onEnter(StateMachine* sm) {
    Serial.println("[SetupState] Entering setup state.");
    sm->displayManager.print("welcome");
}

void SetupState::onUpdate() {
    Serial.println("[SetupState] Running setup logic...");
    delay(1000); // just to slow it down in this demo
}

void SetupState::onExit() {
    Serial.println("[SetupState] Exiting setup state.");
}
