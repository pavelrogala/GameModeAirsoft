#ifndef SETUP_STATE_H
#define SETUP_STATE_H

#include "../StateMachine.h"

class SetupState : public State {
public:
    void onEnter(StateMachine* sm) override;
    void onUpdate() override;
    void onExit() override;
};

#endif
